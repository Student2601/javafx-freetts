/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXRadioButton;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

/**
 * FXML Controller class
 *
 * @author Mudasir Hassan
 */
public class ThemesController implements Initializable {

    @FXML
    private JFXRadioButton Dark_selector;
    @FXML
    private JFXRadioButton light_selector;
    @FXML
    private JFXButton Apply_button;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void Apply_button_Action(ActionEvent event) {
        FXMLController co = new FXMLController();
    if(Dark_selector.isSelected()){
        light_selector.setDisable(true);  
        co.sc.getStylesheets().add("Styles/DarkTheme.css");
        }
        if(light_selector.isSelected()){
        Dark_selector.setDisable(true);
        co.sc.getStylesheets().add("Styles/editor.css");
        }
    }
    
}
